window.App = (function(){
  const $ = (sel,ctx=document) => ctx.querySelector(sel);
  const el = (tag,attrs={},...kids) => {
    const n = document.createElement(tag);
    for(const k in attrs){
      if(k==="class") n.className = attrs[k];
      else if(k==="html") n.innerHTML = attrs[k];
      else if(k.startsWith("on")) n.addEventListener(k.slice(2), attrs[k]);
      else n.setAttribute(k, attrs[k]);
    }
    kids.flat().forEach(c => n.appendChild(typeof c==="string"?document.createTextNode(c):c));
    return n;
  };
  const esc = s => String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

  /* ---------- storage (Artifacts window.storage OU localStorage) ---------- */
  async function guardar(chave,valor){
    const d = JSON.stringify(valor);
    try{ if(window.storage&&window.storage.set) await window.storage.set(chave,d); else localStorage.setItem(chave,d); }catch(e){}
  }
  async function ler(chave){
    try{
      let b=null;
      if(window.storage&&window.storage.get){ const r=await window.storage.get(chave); b=r&&r.value; }
      else b=localStorage.getItem(chave);
      return b?JSON.parse(b):null;
    }catch(e){ return null; }
  }

  /* ---------- perfil do usuário ---------- */
  let perfil = null; // {nick, avatar, id}
  function avatarPorId(id){ return (window.AVATARS||[]).find(a=>a.id===id) || window.AVATARS[0]; }
  function novoId(){ return "u-"+Math.random().toString(36).slice(2,9); }

  const raiz = () => document.getElementById("app");

  /* ================= HOME / PERFIL ================= */
  function telaHome(primeiraVez){
    const av = window.AVATARS;
    let escolhido = perfil ? perfil.avatar : av[0].id;
    const grid = el("div",{class:"avatares"});
    const turmas = ["Turma 1","Turma 2","Turma 3"];
    const cont = el("div");
    [0,1,2].forEach(t=>{
      cont.appendChild(el("div",{class:"turma-tit"}, turmas[t]));
      const g = el("div",{class:"avatares"});
      av.filter(a=>a.turma===t).forEach(a=>{
        const b = el("button",{type:"button","aria-pressed":String(a.id===escolhido),"aria-label":a.nome,html:a.svg});
        b.addEventListener("click",()=>{
          escolhido=a.id;
          g.parentElement.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed","false"));
          cont.querySelectorAll(".avatares button").forEach(x=>{
            if(x.getAttribute("aria-label")===a.nome) x.setAttribute("aria-pressed","true");
          });
        });
        g.appendChild(b);
      });
      cont.appendChild(g);
    });

    const nome = el("input",{type:"text",id:"nk",maxlength:"16",placeholder:"Seu nick",autocomplete:"off",value:perfil?perfil.nick:""});
    const salvar = el("button",{class:"btn",style:"margin-top:20px"}, primeiraVez?"Entrar":"Salvar perfil");
    salvar.addEventListener("click", async ()=>{
      const nk = nome.value.trim();
      if(!nk){ nome.focus(); return; }
      perfil = { nick:nk, avatar:escolhido, id: perfil?perfil.id:novoId() };
      await guardar("app:perfil", perfil);
      telaEstante();
    });
    nome.addEventListener("keydown",e=>{ if(e.key==="Enter") salvar.click(); });

    const voltar = perfil ? el("button",{class:"btn-ghost", onclick:()=>telaEstante()},"Voltar") : null;

    raiz().replaceChildren(
      el("header", primeiraVez?{}:{class:"compacto"},
        primeiraVez
          ? el("div",{}, el("div",{class:"eyebrow"},"Salão de Jogos"), el("h1",{html:'Boa <em>noite</em>'}), el("p",{class:"sub"},"Monte seu perfil: escolha um nick e um bichinho. Fica salvo neste aparelho."))
          : [el("div",{}, el("div",{class:"eyebrow"},"Perfil"), el("h1",{},"Editar")), voltar]
      ),
      el("div",{class:"card"},
        el("label",{class:"rot",for:"nk"},"Nick"), nome,
        el("div",{class:"rot",style:"margin-top:22px"},"Escolha seu bichinho"),
        cont
      ),
      salvar
    );
  }

  /* ================= ESTANTE DE JOGOS ================= */
  const JOGOS = [
    { id:"perfil", nome:"Perfil", emoji:"🕵️", desc:"Descubra a personalidade pelas pistas. Online em times, 1v1 local ou placar de mesa.", pronto:true },
    { id:"quiz", nome:"Quiz Relâmpago", emoji:"⚡", desc:"Perguntas rápidas, quem responde primeiro pontua.", pronto:false },
    { id:"mimica", nome:"Mímica", emoji:"🎭", desc:"Sorteia a palavra, corre o tempo, o time adivinha.", pronto:false }
  ];

  function telaEstante(){
    const a = avatarPorId(perfil.avatar);
    const lista = el("div",{class:"jogos"});
    JOGOS.forEach(j=>{
      const card = el("button",{class:"jogo"+(j.pronto?"":" soon"), type:"button"},
        el("div",{class:"emoji"}, j.emoji),
        el("div",{class:"info"}, el("h2",{},j.nome), el("p",{},j.desc)),
        el("span",{class:"selo"}, j.pronto?"Jogar":"Em breve")
      );
      if(j.pronto) card.addEventListener("click",()=>abrirJogo(j.id));
      lista.appendChild(card);
    });

    raiz().replaceChildren(
      el("header",{class:"compacto"},
        el("div",{class:"saudacao"},
          el("div",{class:"av",html:a.svg}),
          el("div",{}, el("div",{class:"eyebrow"},"Olá"), el("h1",{style:"font-size:30px"}, perfil.nick))
        ),
        el("button",{class:"btn-ghost", onclick:()=>telaHome(false)},"Editar")
      ),
      el("div",{}, el("div",{class:"eyebrow",style:"margin-bottom:2px"},"Seus jogos"), lista),
      el("footer",{html:'Salão de Jogos · comece pelo Perfil, novos jogos entram na estante.'})
    );
  }

  function abrirJogo(id){
    if(id==="perfil") window.Perfil.abrir({ perfil, guardar, ler, voltar:telaEstante, el, esc, avatarPorId });
  }

  /* ================= BOOT ================= */
  async function iniciar(){
    perfil = await ler("app:perfil");
    if(perfil && !perfil.id){ perfil.id = novoId(); await guardar("app:perfil", perfil); }
    if(perfil && perfil.nick) telaEstante(); else telaHome(true);
  }

  return { iniciar, el, esc, guardar, ler };
})();
