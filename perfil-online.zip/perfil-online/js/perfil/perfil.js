window.Perfil = (function(){
  let ctx, el, esc, raiz;
  let BARALHO = [];
  try{
    BARALHO = JSON.parse(decodeURIComponent(atob(window.DECK_B64).split("").map(c=>"%"+c.charCodeAt(0).toString(16).padStart(2,"0")).join("")));
  }catch(e){ BARALHO=[]; }

  const $ = id => document.getElementById(id);
  function tela(node){ raiz().replaceChildren(node); window.scrollTo({top:0}); }
  function cabec(titulo, onVoltar, extra){
    return el("header",{class:"compacto"},
      el("div",{}, el("div",{class:"eyebrow"},"Perfil"), el("h1",{}, titulo)),
      extra || el("button",{class:"btn-ghost", onclick:onVoltar}, "Voltar")
    );
  }

  /* ============ APITO + RELÓGIO ============ */
  let timerId=null, restante=60, relBar=null, relTxt=null, relBox=null;
  function apitar(){
    try{
      const ac=new (window.AudioContext||window.webkitAudioContext)();
      [0,.25].forEach(t0=>{const o=ac.createOscillator(),g=ac.createGain();o.connect(g);g.connect(ac.destination);
        o.type="triangle";o.frequency.value=760;const t=ac.currentTime+t0;
        g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.25,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+.2);
        o.start(t);o.stop(t+.25);});
    }catch(e){}
  }
  function pintaRel(){
    if(!relTxt) return;
    const m=Math.floor(restante/60),s=restante%60;
    relTxt.textContent = restante===0?"tempo!":`${m}:${String(s).padStart(2,"0")}`;
    relBar.style.width=(restante/60*100)+"%";
  }
  function paraRel(){ if(timerId){clearInterval(timerId);timerId=null;} }
  function iniciaRel(){
    paraRel(); restante=60; if(relBox) relBox.classList.remove("acabou"); pintaRel();
    timerId=setInterval(()=>{ restante--; if(restante<=0){restante=0;paraRel();if(relBox)relBox.classList.add("acabou");apitar();} pintaRel(); },1000);
  }
  document.addEventListener("visibilitychange",()=>{ if(document.hidden) paraRel(); });

  /* ============ MENU DO PERFIL ============ */
  function menu(){
    const opt = (tag,titulo,desc,fn,off) => {
      const b=el("button",{class:"jogo"+(off?" soon":""),type:"button"},
        el("div",{class:"emoji"}, tag),
        el("div",{class:"info"}, el("h2",{},titulo), el("p",{},desc)),
        el("span",{class:"selo"}, off?"Indisponível":"Abrir"));
      if(!off) b.addEventListener("click",fn);
      return b;
    };
    const online = ctx.net && ctx.net.disponivel();
    tela(el("div",{},
      cabec("Perfil", ctx.voltar),
      el("div",{class:"jogos"},
        opt("🌐","Jogar online", online?"Crie uma sala, a galera entra pelo código e cai sorteada num time.":"Configure o Supabase (config.js) para liberar.", modoOnlineHome, !online),
        opt("👥","1v1 no mesmo celular","Sem internet: vocês se revezam passando o aparelho.", modoLocalSetup),
        opt("🏆","Só marcar pontos","Placar de mesa pra até 8, quando jogam com as cartas de papel.", modoPlacarSetup)
      ),
      el("footer",{}, BARALHO.length+" cartas no baralho")
    ));
  }

  /* util baralho */
  function sorteia(usadas){
    let livres=BARALHO.map((_,i)=>i).filter(i=>!usadas.includes(i));
    if(!livres.length){ usadas.length=0; livres=BARALHO.map((_,i)=>i); }
    return livres[Math.floor(Math.random()*livres.length)];
  }

  /* ====================================================================
     MODO 1 — PLACAR DE MESA
     ==================================================================== */
  let pl;
  async function carregaPlacar(){ pl = await ctx.ler("perfil:placar") || {jogadores:[],rodada:1,pendente:{},historico:[]}; }
  function salvaPlacar(){ ctx.guardar("perfil:placar", pl); }

  async function modoPlacarSetup(){
    await carregaPlacar();
    const input=el("input",{type:"text",maxlength:"18",placeholder:"Nome do jogador",autocomplete:"off"});
    const listaEl=el("ul",{class:"lista"});
    const add=el("button",{class:"btn"},"Adicionar");
    const iniciar=el("button",{class:"btn",style:"margin-top:20px"},"Começar a marcar");
    function repinta(){
      listaEl.replaceChildren(...pl.jogadores.map((j,i)=>{
        const rm=el("button",{type:"button","aria-label":"Remover "+j.nome},"×");
        rm.addEventListener("click",()=>{ pl.jogadores=pl.jogadores.filter(x=>x.id!==j.id); salvaPlacar(); repinta(); });
        return el("li",{}, el("span",{class:"n"},String(i+1).padStart(2,"0")), el("span",{class:"nm"},j.nome), rm);
      }));
      iniciar.disabled=pl.jogadores.length<2;
      add.disabled=pl.jogadores.length>=8;
      input.disabled=pl.jogadores.length>=8;
      input.placeholder=pl.jogadores.length>=8?"Grupo completo (8)":"Nome do jogador";
    }
    function addJ(){ const n=input.value.trim(); if(!n||pl.jogadores.length>=8) return;
      pl.jogadores.push({id:Date.now()+"-"+Math.random().toString(36).slice(2,6),nome:n,pontos:0});
      input.value="";input.focus();salvaPlacar();repinta(); }
    add.addEventListener("click",addJ);
    input.addEventListener("keydown",e=>{if(e.key==="Enter")addJ();});
    iniciar.addEventListener("click",()=>{ if(pl.jogadores.length>=2) modoPlacarJogo(); });
    repinta();
    tela(el("div",{},
      cabec("Placar", menu),
      el("div",{class:"card"}, el("p",{class:"hint"},"Nome de quem vai jogar, até 8 pessoas."), el("div",{class:"campo"},input,add), listaEl),
      iniciar,
      el("footer",{},"Precisa de pelo menos 2 jogadores.")
    ));
  }

  function modoPlacarJogo(){
    const box=el("div",{class:"jogadores"});
    const status=el("p",{class:"status"});
    const encerrar=el("button",{class:"btn"});
    const desfazer=el("button",{class:"btn-ghost"});
    const zerar=el("button",{class:"btn-ghost"},"Novo placar");
    function marca(id,pts){ if(pl.pendente[id]===pts) delete pl.pendente[id]; else pl.pendente[id]=pts; salvaPlacar(); repinta(); }
    function repinta(){
      const ord=[...pl.jogadores].sort((a,b)=>b.pontos-a.pontos);
      const topo=ord.length?ord[0].pontos:0;
      box.replaceChildren(...ord.map((j,i)=>{
        const g=pl.pendente[j.id];
        const trilha=el("div",{class:"trilha"});
        for(let p=1;p<=10;p++){ const b=el("button",{type:"button","aria-pressed":String(g===p),"aria-label":`${p} para ${j.nome}`},String(p));
          b.addEventListener("click",()=>marca(j.id,p)); trilha.appendChild(b); }
        return el("div",{class:"jogador"+(j.pontos===topo&&topo>0?" lider":"")},
          el("div",{class:"topo"}, el("span",{class:"pos"},(i+1)+"º"), el("span",{class:"nm-g"},j.nome),
            g?el("span",{class:"ganho"},"+"+g):"", el("span",{class:"total"},String(j.pontos))),
          trilha);
      }));
      const n=Object.keys(pl.pendente).length, soma=Object.values(pl.pendente).reduce((a,b)=>a+b,0);
      status.textContent = n===0?"Ninguém pontuou ainda nesta rodada":`${n} pontuando · ${soma} pontos na mesa`;
      encerrar.textContent="Encerrar rodada "+pl.rodada;
      desfazer.textContent=n?"Limpar rodada":"Desfazer rodada";
      desfazer.disabled=!n&&!pl.historico.length;
    }
    encerrar.addEventListener("click",()=>{
      const g=Object.assign({},pl.pendente);
      pl.jogadores.forEach(j=>{if(g[j.id])j.pontos+=g[j.id];});
      pl.historico.push({rodada:pl.rodada,ganhos:g}); pl.rodada++; pl.pendente={};
      salvaPlacar(); repinta(); window.scrollTo({top:0,behavior:"smooth"});
    });
    desfazer.addEventListener("click",()=>{
      if(Object.keys(pl.pendente).length){ pl.pendente={}; salvaPlacar(); repinta(); return; }
      const u=pl.historico.pop(); if(!u) return;
      pl.jogadores.forEach(j=>{if(u.ganhos[j.id])j.pontos=Math.max(0,j.pontos-u.ganhos[j.id]);});
      pl.rodada=Math.max(1,pl.rodada-1); salvaPlacar(); repinta();
    });
    zerar.addEventListener("click",()=>{ if(!confirm("Apagar este placar?"))return;
      pl={jogadores:[],rodada:1,pendente:{},historico:[]}; salvaPlacar(); modoPlacarSetup(); });
    repinta();
    tela(el("div",{},
      cabec("Placar", menu),
      box,
      el("div",{class:"barra"}, status, encerrar, el("div",{class:"acoes"}, desfazer, zerar))
    ));
  }

  /* ====================================================================
     MODO 2 — 1v1 LOCAL (revezando o celular)
     ==================================================================== */
  let lg;
  function modoLocalSetup(){
    const j1=el("input",{type:"text",maxlength:"14",placeholder:"Nome",autocomplete:"off"});
    const j2=el("input",{type:"text",maxlength:"14",placeholder:"Nome",autocomplete:"off"});
    const meta=el("input",{type:"number",value:"50",min:"10",max:"200",step:"5"});
    const comecar=el("button",{class:"btn",style:"margin-top:20px"},"Começar partida");
    comecar.addEventListener("click",()=>{
      lg={nomes:[j1.value.trim()||"Jogador 1", j2.value.trim()||"Jogador 2"],
          pontos:[0,0],cartas:[0,0],meta:Math.max(10,Math.min(200,parseInt(meta.value,10)||50)),
          vez:0,carta:null,dica:0,usadas:[]};
      localPassagem();
    });
    tela(el("div",{},
      cabec("1v1 local", menu),
      el("div",{class:"card"}, el("div",{style:"display:flex;flex-direction:column;gap:20px"},
        el("div",{}, el("label",{class:"rot"},"Jogador 1"), j1),
        el("div",{}, el("label",{class:"rot"},"Jogador 2"), j2),
        el("div",{}, el("label",{class:"rot"},"Pontos para vencer"), meta)
      )),
      el("div",{class:"card"}, el("h2",{style:"font-size:19px"},"Como funciona"),
        el("p",{class:"hint",style:"margin:12px 0 0"},
          "Vocês se revezam: um adivinha, o outro segura o celular e lê. As dez dicas aparecem juntas, embaçadas; cada toque libera a de baixo. A dica de cima vale 10 e a de baixo vale 1.")),
      comecar
    ));
  }

  function placarDupla(vez){
    return el("div",{class:"placarfixo"},
      ...lg.nomes.map((n,i)=>el("div",{class:"pl"+(i===vez?" vez":"")},
        el("div",{class:"q"}, n+(i===vez?" · adivinha":"")), el("div",{class:"v"}, String(lg.pontos[i])))));
  }
  function localPassagem(){
    paraRel();
    const quem=lg.nomes[lg.vez], leitor=lg.nomes[1-lg.vez];
    const abrir=el("button",{class:"btn"}, leitor+", abrir a carta");
    abrir.addEventListener("click",()=>{ lg.carta=sorteia(lg.usadas); lg.dica=0; localCarta(false); });
    tela(el("div",{},
      placarDupla(lg.vez),
      el("div",{class:"card passagem"},
        el("div",{class:"seta"},"↓"), el("h2",{},"Vez de "+quem),
        el("p",{}, "Entregue o celular para "+leitor+" — ele lê as dicas. "+quem+", não olhe a tela."),
        abrir),
      el("div",{class:"acoes"}, el("button",{class:"btn-ghost",onclick:()=>{ if(confirm("Encerrar a partida?")){paraRel();menu();} }},"Encerrar partida"))
    ));
  }
  function localCarta(rolar){
    const c=BARALHO[lg.carta];
    relBox=el("div",{class:"relogio"}); relTxt=el("span"); relBar=el("i");
    relBox.append(relTxt, el("span",{class:"bar"}, relBar));
    const pistas=el("ol",{class:"pistas"});
    const btnProx=el("button",{class:"btn btn-linha larga"});
    function repinta(){
      pistas.replaceChildren(...c.d.map((t,i)=>{
        const aberta=i<=lg.dica;
        return el("li",{class:"pista "+(aberta?"aberta":"trancada")+(i===lg.dica?" atual":"")},
          el("span",{class:"v"},String(10-i)), el("span",{class:"t"}, aberta?t:t));
      }));
      btnProx.textContent = lg.dica>=9?"Ninguém acertou — encerrar":"Próxima dica";
      valBox.textContent=String(10-lg.dica);
    }
    function avanca(){ if(lg.dica>=9){ localReveal(0); return; } lg.dica++; repinta(); iniciaRel();
      const atual=pistas.children[lg.dica]; if(atual) atual.scrollIntoView && atual.scrollIntoView({block:"center",behavior:"smooth"}); }
    btnProx.addEventListener("click",avanca);
    const acertou=el("button",{class:"btn btn-mint larga"},"Acertou");
    acertou.addEventListener("click",()=>localReveal(10-lg.dica));
    const pular=el("button",{class:"btn-ghost larga",style:"width:100%"},"Já conhece essa carta — trocar");
    pular.addEventListener("click",()=>{ lg.carta=sorteia(lg.usadas); lg.dica=0; repinta(); iniciaRel(); window.scrollTo({top:0,behavior:"smooth"}); });

    const valBox=el("strong",{},String(10-lg.dica));
    tela(el("div",{},
      placarDupla(lg.vez),
      el("div",{class:"carta"},
        el("div",{class:"carta-topo"},
          el("div",{}, el("div",{class:"cat"},"Personalidade · "+c.c),
            el("div",{style:"font-size:13px;color:var(--muted);margin-top:4px"}, lg.nomes[lg.vez]+" está adivinhando")),
          el("div",{class:"valor"}, el("span",{},"Vale agora"), valBox)),
        el("div",{class:"resposta"}, el("span",{},"Só o leitor vê"), el("strong",{}, c.n)),
        relBox, pistas),
      el("div",{class:"controles"}, acertou, btnProx, pular)
    ));
    repinta(); iniciaRel();
    if(rolar){ const atual=pistas.children[lg.dica]; if(atual&&atual.scrollIntoView) atual.scrollIntoView({block:"center"}); }
  }
  function localReveal(pontos){
    paraRel();
    const c=BARALHO[lg.carta], quem=lg.vez;
    lg.pontos[quem]+=pontos; lg.cartas[quem]++;
    const empatadas=lg.cartas[0]===lg.cartas[1];
    const lider=lg.pontos[0]===lg.pontos[1]?-1:(lg.pontos[0]>lg.pontos[1]?0:1);
    const acabou=empatadas&&lider>=0&&lg.pontos[lider]>=lg.meta;
    lg.vez=1-lg.vez;
    const cont=el("button",{class:"btn"}, acabou?"Ver resultado":"Próxima carta");
    cont.addEventListener("click",()=> acabou?localFim():localPassagem());
    tela(el("div",{class:"card revelacao"},
      el("div",{class:"eyebrow"}, pontos>0?("Acertou na dica de "+(10-lg.dica)+" pontos"):"Passou as 10 dicas"),
      el("div",{class:"nome-final"}, c.n),
      el("div",{class:"pts"+(pontos>0?"":" zero")}, pontos>0?("+"+pontos):"0"),
      el("div",{class:"detalhe"}, lg.nomes[quem]+" agora tem "+lg.pontos[quem]+" de "+lg.meta),
      cont
    ));
  }
  function localFim(){
    const venc=lg.pontos[0]>lg.pontos[1]?0:1;
    const rev=el("button",{class:"btn"},"Revanche");
    rev.addEventListener("click",()=>{ lg.pontos=[0,0];lg.cartas=[0,0];lg.vez=0; localPassagem(); });
    tela(el("div",{class:"card fim"},
      el("div",{class:"trofeu"},"🏆"), el("div",{class:"eyebrow"},"Fim de partida"),
      el("h2",{}, lg.nomes[venc]+" venceu"),
      el("div",{class:"linha"}, `${lg.nomes[0]} ${lg.pontos[0]} × ${lg.pontos[1]} ${lg.nomes[1]}`),
      el("div",{style:"margin-top:34px"}, rev),
      el("div",{class:"acoes"}, el("button",{class:"btn-ghost",onclick:menu},"Voltar"))
    ));
  }

  /* ====================================================================
     MODO 3 — ONLINE EM TIMES (Supabase)  [beta]
     ==================================================================== */
  const Net = () => ctx.net;
  let sala=null;         // {code}
  let estado=null;       // snapshot do state remoto
  let desinscrever=null;
  const eu = () => ctx.perfil;

  function codigoNovo(){ const L="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s=""; for(let i=0;i<4;i++)s+=L[Math.floor(Math.random()*L.length)]; return s; }

  const TIMES = { A:{nome:"Vermelho", cls:"a"}, B:{nome:"Azul", cls:"b"} };
  function contaTimes(s){ let a=0,b=0; s.order.forEach(id=>{const m=s.members[id]; if(m&&m.team==="A")a++; else if(m&&m.team==="B")b++;}); return {a,b}; }
  function sorteiaTime(s){ const {a,b}=contaTimes(s); if(a<b)return "A"; if(b<a)return "B"; return Math.random()<0.5?"A":"B"; }
  function embaralhaTimes(s){
    const ids=[...s.order].filter(id=>s.members[id]);
    for(let i=ids.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [ids[i],ids[j]]=[ids[j],ids[i]]; }
    ids.forEach((id,k)=>{ s.members[id].team = k%2===0 ? "A" : "B"; });
  }

  function modoOnlineHome(){
    const codeInput=el("input",{type:"text",maxlength:"4",placeholder:"CÓDIGO",autocomplete:"off",style:"text-transform:uppercase;text-align:center;letter-spacing:.3em;font-family:'Space Mono',monospace"});
    const criar=el("button",{class:"btn"},"Criar sala nova");
    const entrar=el("button",{class:"btn btn-linha"},"Entrar com código");
    criar.addEventListener("click",criarSala);
    entrar.addEventListener("click",()=>{ const c=codeInput.value.trim().toUpperCase(); if(c.length>=4) entrarSala(c); });
    tela(el("div",{},
      cabec("Online", menu),
      el("div",{class:"card"},
        el("p",{class:"hint"},"Uma pessoa cria a sala e passa o código de 4 letras. Quem entra cai sorteado num time — o host pode reembaralhar antes de começar."),
        criar,
        el("div",{style:"height:16px"}),
        el("label",{class:"rot"},"Já tem um código?"),
        el("div",{class:"campo"}, codeInput, entrar)
      ),
      el("footer",{},"Modo em teste. Se algo travar, recarregue e entre de novo na sala.")
    ));
  }

  async function criarSala(){
    const code=codigoNovo();
    const st={
      host:eu().id, phase:"lobby", meta:50,
      members:{ [eu().id]:{nick:eu().nick, avatar:eu().avatar, team:(Math.random()<0.5?"A":"B")} },
      order:[eu().id], turn:"A", readerId:null, readerRot:{A:0,B:0},
      card:null, dica:0, scores:{A:0,B:0}, cartas:{A:0,B:0}, used:[], last:null
    };
    try{ await Net().criarSala(code, st); sala={code}; ligarCanal(); estado=st; renderOnline(); }
    catch(e){ alert("Não consegui criar a sala. Confira o config.js e o SQL do Supabase."); console.error(e); }
  }
  async function entrarSala(code){
    try{
      const st=await Net().lerSala(code);
      if(!st){ alert("Sala "+code+" não encontrada."); return; }
      const novo=await Net().alterar(code, s=>{
        if(!s.members[eu().id]){
          s.members[eu().id]={nick:eu().nick,avatar:eu().avatar,team:null};
          s.order.push(eu().id);
          s.members[eu().id].team = sorteiaTime(s);
        }
        return s;
      });
      sala={code}; ligarCanal(); estado=novo; renderOnline();
    }catch(e){ alert("Não consegui entrar na sala."); console.error(e); }
  }
  function ligarCanal(){
    if(desinscrever){ desinscrever(); desinscrever=null; }
    desinscrever=Net().inscrever(sala.code, st=>{ if(st){ estado=st; renderOnline(); } });
  }
  function sairOnline(){
    paraRel();
    if(desinscrever){ desinscrever(); desinscrever=null; }
    if(sala) Net().alterar(sala.code, s=>{ if(s.members[eu().id]){ delete s.members[eu().id]; s.order=s.order.filter(i=>i!==eu().id);} return s; }).catch(()=>{});
    sala=null; estado=null; menu();
  }
  async function mutar(f){
    try{ const novo=await Net().alterar(sala.code, f); if(novo){ estado=novo; renderOnline(); } }
    catch(e){ console.error(e); }
  }

  const souHost = () => estado && estado.host===eu().id;
  const meuTime = () => estado && estado.members[eu().id] && estado.members[eu().id].team;
  const souLeitor = () => estado && estado.readerId===eu().id;

  function proximoLeitor(s, timeQueLe){
    const membros=s.order.filter(id=>s.members[id] && s.members[id].team===timeQueLe);
    if(!membros.length) return null;
    const p=s.readerRot[timeQueLe]%membros.length;
    s.readerRot[timeQueLe]=(s.readerRot[timeQueLe]+1)%membros.length;
    return membros[p];
  }

  function renderOnline(){
    if(!estado) return;
    if(estado.phase==="lobby") return lobby();
    if(estado.phase==="card") return cartaOnline();
    if(estado.phase==="reveal") return revealOnline();
    if(estado.phase==="over") return fimOnline();
  }
  function avatarMini(id){ const a=ctx.avatarPorId(id); return el("div",{class:"av",html:a.svg}); }

  function lobby(){
    const membrosDoTime=t=>estado.order.filter(i=>estado.members[i]&&estado.members[i].team===t).map(i=>{
      const m=estado.members[i];
      return el("div",{class:"membro"+(i===eu().id?" eu":"")}, avatarMini(m.avatar), el("span",{}, m.nick + (i===estado.host?" 👑":"")));
    });
    const timeA=el("div",{class:"time a"}, el("h3",{},"Time Vermelho"), ...membrosDoTime("A"));
    const timeB=el("div",{class:"time b"}, el("h3",{},"Time Azul"), ...membrosDoTime("B"));

    const mt=meuTime();
    const seuTime = mt ? el("div",{class:"seu-time"}, "Você caiu no ", el("b",{class:TIMES[mt].cls}, "Time "+TIMES[mt].nome)) : "";

    const {a,b}=contaTimes(estado);
    const podeComecar=souHost() && a>=1 && b>=1;

    const embaralhar=el("button",{class:"btn-linha",style:"margin-top:16px"},"Embaralhar times");
    embaralhar.addEventListener("click",()=>mutar(s=>{ embaralhaTimes(s); return s; }));

    const comecar=el("button",{class:"btn",style:"margin-top:10px"},"Começar partida");
    comecar.disabled=!podeComecar;
    comecar.addEventListener("click",()=>mutar(s=>{
      s.phase="card"; s.turn="A"; s.card=sorteia(s.used); s.dica=0;
      s.readerId=proximoLeitor(s,"B");
      return s;
    }));

    tela(el("div",{},
      cabec("Sala", null, el("button",{class:"btn-ghost",onclick:sairOnline},"Sair")),
      el("div",{class:"card"},
        el("div",{class:"eyebrow",style:"text-align:center"},"Código da sala"),
        el("div",{class:"codigo"}, sala.code),
        el("p",{class:"aviso"},"Passe esse código pra galera entrar."),
        el("div",{class:"times"}, timeA, timeB),
        seuTime,
        souHost()? el("div",{}, embaralhar, comecar) : el("p",{class:"aviso",style:"margin-top:18px"},"Esperando o host começar…")
      ),
      el("footer",{}, podeComecar?"Os dois times têm gente ✓":"Cada time precisa de ao menos 1 pessoa.")
    ));
  }

  function placarTimes(){
    return el("div",{class:"placarfixo"},
      el("div",{class:"pl a"+(estado.turn==="A"?" vez":"")}, el("div",{class:"q"},"Vermelho"+(estado.turn==="A"?" · adivinha":"")), el("div",{class:"v"}, String(estado.scores.A))),
      el("div",{class:"pl b"+(estado.turn==="B"?" vez":"")}, el("div",{class:"q"},"Azul"+(estado.turn==="B"?" · adivinha":"")), el("div",{class:"v"}, String(estado.scores.B))));
  }

  function cartaOnline(){
    const c=BARALHO[estado.card];
    const leitor=souLeitor();
    const nomeLeitor=estado.members[estado.readerId]?estado.members[estado.readerId].nick:"alguém";
    const timeVez=TIMES[estado.turn].nome;

    relBox=el("div",{class:"relogio"}); relTxt=el("span"); relBar=el("i");
    relBox.append(relTxt, el("span",{class:"bar"}, relBar));

    const pistas=el("ol",{class:"pistas"});
    c.d.forEach((t,i)=>{
      const aberta=i<=estado.dica;
      pistas.appendChild(el("li",{class:"pista "+(aberta?"aberta":"trancada")+(i===estado.dica?" atual":"")},
        el("span",{class:"v"},String(10-i)), el("span",{class:"t"}, t)));
    });

    let controles;
    if(leitor){
      const prox=el("button",{class:"btn btn-linha larga"}, estado.dica>=9?"Ninguém acertou — encerrar":"Próxima dica");
      prox.addEventListener("click",()=>{ if(estado.dica>=9) return encerraOnline(0); mutar(s=>{ s.dica=Math.min(9,s.dica+1); return s; }); });
      const acertou=el("button",{class:"btn btn-mint larga"},"Time "+timeVez+" acertou");
      acertou.addEventListener("click",()=>encerraOnline(10-estado.dica));
      const pular=el("button",{class:"btn-ghost larga",style:"width:100%"},"Trocar carta");
      pular.addEventListener("click",()=>mutar(s=>{ s.card=sorteia(s.used); s.dica=0; return s; }));
      controles=el("div",{class:"controles"}, acertou, prox, pular);
      iniciaRel();
    } else {
      controles=el("p",{class:"aviso"}, nomeLeitor+" está lendo as dicas para o Time "+timeVez+". Acompanhe as pistas acima.");
      paraRel();
    }

    tela(el("div",{},
      placarTimes(),
      el("div",{class:"carta"},
        el("div",{class:"carta-topo"},
          el("div",{}, el("div",{class:"cat"},"Personalidade · "+c.c),
            el("div",{style:"font-size:13px;color:var(--slate);margin-top:4px;font-weight:600"}, "Time "+timeVez+" adivinha"+(leitor?" · você lê":""))),
          el("div",{class:"valor"}, el("span",{},"Vale agora"), el("strong",{}, String(10-estado.dica)))),
        leitor?el("div",{class:"resposta"}, el("span",{},"Só você (leitor) vê"), el("strong",{}, c.n)):"",
        relBox, pistas),
      controles,
      el("div",{class:"acoes"}, el("button",{class:"btn-ghost",onclick:sairOnline},"Sair da sala"))
    ));
  }

  function encerraOnline(pontos){
    paraRel();
    mutar(s=>{
      s.scores[s.turn]+=pontos; s.cartas[s.turn]++;
      s.last={ team:s.turn, name:BARALHO[s.card].n, pts:pontos, dica:s.dica };
      const empat=s.cartas.A===s.cartas.B;
      const lider=s.scores.A===s.scores.B?null:(s.scores.A>s.scores.B?"A":"B");
      s.phase=(empat&&lider&&s.scores[lider]>=s.meta)?"over":"reveal";
      return s;
    });
  }

  function revealOnline(){
    const L=estado.last||{team:"A",name:"—",pts:0,dica:0};
    const timeL=TIMES[L.team].nome;
    const cont=el("button",{class:"btn"},"Próxima carta");
    if(souHost()){
      cont.addEventListener("click",()=>mutar(s=>{
        s.turn = s.turn==="A"?"B":"A";
        s.readerId = proximoLeitor(s, s.turn==="A"?"B":"A");
        s.card=sorteia(s.used); s.dica=0; s.phase="card"; s.last=null;
        return s;
      }));
    } else { cont.disabled=true; cont.textContent="Esperando o host…"; }
    tela(el("div",{},
      placarTimes(),
      el("div",{class:"card revelacao"},
        el("div",{class:"eyebrow"}, L.pts>0?("Time "+timeL+" acertou na dica de "+(10-L.dica)+" pontos"):("Time "+timeL+" passou as 10 dicas")),
        el("div",{class:"nome-final"}, L.name),
        el("div",{class:"pts"+(L.pts>0?"":" zero")}, L.pts>0?("+"+L.pts):"0"),
        el("div",{class:"detalhe"}, "Vermelho "+estado.scores.A+" × "+estado.scores.B+" Azul"),
        cont),
      el("div",{class:"acoes"}, el("button",{class:"btn-ghost",onclick:sairOnline},"Sair da sala"))
    ));
  }

  function fimOnline(){
    const venc=estado.scores.A>estado.scores.B?"A":"B";
    const rev=el("button",{class:"btn"},"Revanche");
    rev.disabled=!souHost();
    if(souHost()) rev.addEventListener("click",()=>mutar(s=>{
      s.scores={A:0,B:0}; s.cartas={A:0,B:0}; s.turn="A"; s.phase="card";
      s.card=sorteia(s.used); s.dica=0; s.readerId=proximoLeitor(s,"B"); s.last=null; return s;
    }));
    tela(el("div",{},
      placarTimes(),
      el("div",{class:"card fim"},
        el("div",{class:"trofeu"},"🏆"), el("div",{class:"eyebrow"},"Fim de partida"),
        el("h2",{}, "Time "+TIMES[venc].nome+" venceu"),
        el("div",{class:"linha"}, "Vermelho "+estado.scores.A+" × "+estado.scores.B+" Azul"),
        el("div",{style:"margin-top:34px"}, rev),
        el("div",{class:"acoes"}, el("button",{class:"btn-ghost",onclick:sairOnline},"Sair da sala"))
    )));
  }

  function abrir(context){
    ctx = context; el = context.el; esc = context.esc;
    ctx.net = window.Net;
    raiz = () => document.getElementById("app");
    menu();
  }
  return { abrir };
})();
