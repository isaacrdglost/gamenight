/* 12 bichinhos gerados em SVG puro. Sem imagem externa.
   Três turmas de quatro só pra dar variedade na hora de escolher. */
(function(){
  const P = {
    manga:{bg:"#FF9F5A",dark:"#7A3B12"},
    uva:{bg:"#A98BFF",dark:"#38246E"},
    limao:{bg:"#8BD96B",dark:"#265417"},
    ceu:{bg:"#5AC8FF",dark:"#0E3F5C"},
    rosa:{bg:"#FF8FC5",dark:"#7A2450"},
    menta:{bg:"#5AE0B4",dark:"#0B4A38"},
    coral:{bg:"#FF7A7A",dark:"#7A1F1F"},
    ouro:{bg:"#FFC94D",dark:"#6E4B00"},
    lavanda:{bg:"#C9A7FF",dark:"#4A2E7A"},
    agua:{bg:"#66E0D2",dark:"#0B4E48"},
    tijolo:{bg:"#E8845A",dark:"#5E2A12"},
    pervinca:{bg:"#8FA3FF",dark:"#26327A"}
  };

  function face(pal, inner){
    const {bg,dark} = pal;
    return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img">
      <rect x="8" y="8" width="84" height="84" rx="26" fill="${bg}"/>
      ${inner(dark,bg)}
    </svg>`;
  }
  const eyes = (d,dx=0) => `<circle cx="${38+dx}" cy="52" r="6.5" fill="#fff"/><circle cx="${62+dx}" cy="52" r="6.5" fill="#fff"/>
     <circle cx="${39+dx}" cy="53" r="3" fill="${d}"/><circle cx="${63+dx}" cy="53" r="3" fill="${d}"/>`;
  const blush = c => `<ellipse cx="30" cy="64" rx="6" ry="3.5" fill="${c}" opacity=".5"/><ellipse cx="70" cy="64" rx="6" ry="3.5" fill="${c}" opacity=".5"/>`;
  const smile = d => `<path d="M40 66 Q50 74 60 66" stroke="${d}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`;

  // cada bichinho: id, nome, paleta, função de detalhe
  const spec = [
    // turma 1
    ["gato","Gato",P.ouro,(d,b)=>`<path d="M26 14 L34 34 L18 30 Z" fill="${b}"/><path d="M74 14 L66 34 L82 30 Z" fill="${b}"/>${eyes(d)}${blush(d)}<path d="M50 60 l-4 4 4 4 4-4z" fill="${d}"/><path d="M44 64 h-14 M56 64 h14" stroke="${d}" stroke-width="2" stroke-linecap="round"/>`],
    ["jacare","Jacarezinho",P.limao,(d,b)=>`<ellipse cx="50" cy="74" rx="26" ry="14" fill="${b}"/><path d="M28 74 h44" stroke="${d}" stroke-width="2.5"/><path d="M32 74 l3 -5 M40 74 l3 -5 M50 74 l3 -5 M58 74 l3 -5 M66 74 l3 -5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>${eyes(d)}<circle cx="40" cy="70" r="2" fill="${d}"/><circle cx="60" cy="70" r="2" fill="${d}"/>`],
    ["robo","Robôzinho",P.ceu,(d,b)=>`<line x1="50" y1="8" x2="50" y2="0" stroke="${d}" stroke-width="3"/><circle cx="50" cy="0" r="4" fill="${d}"/><rect x="30" y="46" width="40" height="20" rx="6" fill="#fff"/><rect x="36" y="52" width="8" height="8" rx="2" fill="${d}"/><rect x="56" y="52" width="8" height="8" rx="2" fill="${d}"/><path d="M42 72 h16" stroke="${d}" stroke-width="3" stroke-linecap="round"/>`],
    ["fantasma","Fantasminha",P.uva,(d,b)=>`${eyes(d)}<ellipse cx="50" cy="70" rx="7" ry="9" fill="${d}"/>${blush("#fff")}`],
    // turma 2
    ["coelho","Coelho",P.rosa,(d,b)=>`<rect x="34" y="-4" width="10" height="26" rx="5" fill="${b}"/><rect x="56" y="-4" width="10" height="26" rx="5" fill="${b}"/><rect x="37" y="0" width="4" height="16" rx="2" fill="#fff" opacity=".6"/><rect x="59" y="0" width="4" height="16" rx="2" fill="#fff" opacity=".6"/>${eyes(d)}${blush(d)}${smile(d)}`],
    ["sapo","Sapinho",P.menta,(d,b)=>`<circle cx="34" cy="34" r="12" fill="${b}"/><circle cx="66" cy="34" r="12" fill="${b}"/><circle cx="34" cy="34" r="6" fill="#fff"/><circle cx="66" cy="34" r="6" fill="#fff"/><circle cx="35" cy="35" r="3" fill="${d}"/><circle cx="67" cy="35" r="3" fill="${d}"/><path d="M38 62 Q50 72 62 62" stroke="${d}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`],
    ["abelha","Abelhinha",P.ouro,(d,b)=>`<path d="M22 40 q-10 -6 -4 -14" stroke="${d}" stroke-width="2.5" fill="none"/><path d="M78 40 q10 -6 4 -14" stroke="${d}" stroke-width="2.5" fill="none"/><circle cx="18" cy="24" r="4" fill="#fff" stroke="${d}" stroke-width="1.5"/><circle cx="82" cy="24" r="4" fill="#fff" stroke="${d}" stroke-width="1.5"/><path d="M18 74 h64 M22 84 h56" stroke="${d}" stroke-width="4" stroke-linecap="round" opacity=".55"/>${eyes(d)}${smile(d)}`],
    ["polvo","Polvinho",P.coral,(d,b)=>`${eyes(d)}${blush(d)}${smile(d)}<path d="M28 84 q-4 8 2 10 M40 86 q-2 8 3 10 M60 86 q2 8 -3 10 M72 84 q4 8 -2 10" stroke="${b}" stroke-width="7" fill="none" stroke-linecap="round"/>`],
    // turma 3
    ["dino","Dininho",P.agua,(d,b)=>`<path d="M40 12 l4 8 6 -8 6 8 4 -8" stroke="${d}" stroke-width="3" fill="none" stroke-linejoin="round"/>${eyes(d)}${blush(d)}<path d="M40 66 h20 v4 h-20z" fill="${d}"/>`],
    ["morcego","Morceguinho",P.lavanda,(d,b)=>`<path d="M8 40 q10 -14 22 -6 M92 40 q-10 -14 -22 -6" fill="${b}" stroke="${d}" stroke-width="1.5"/>${eyes(d)}<path d="M44 68 l6 6 6 -6" stroke="${d}" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`],
    ["estrela","Estrelinha",P.tijolo,(d,b)=>`<path d="M50 20 l6 12 13 2 -9 9 2 13 -12 -6 -12 6 2 -13 -9 -9 13 -2z" fill="${b}" stroke="${d}" stroke-width="1.5" transform="translate(0 40) scale(.55) translate(0 -20)" opacity=".0"/>${eyes(d)}${blush(d)}${smile(d)}<path d="M14 20 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" fill="#fff" opacity=".8"/>`],
    ["nuvem","Nuvenzinha",P.pervinca,(d,b)=>`<circle cx="30" cy="30" r="10" fill="#fff" opacity=".7"/><circle cx="50" cy="24" r="12" fill="#fff" opacity=".7"/><circle cx="70" cy="30" r="10" fill="#fff" opacity=".7"/>${eyes(d)}${blush(d)}${smile(d)}`]
  ];

  window.AVATARS = spec.map(([id,nome,pal,inner],i) => ({
    id, nome, turma: Math.floor(i/4),
    svg: face(pal, inner)
  }));
})();
