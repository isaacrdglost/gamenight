/* Cole aqui as chaves do seu projeto Supabase para ligar o modo ONLINE.
   Onde achar: painel do Supabase > Project Settings > Data API / API Keys.
   - PROJECT URL  -> algo como https://xxxxxxxx.supabase.co
   - anon public  -> uma chave longa que começa com "eyJ..."
   A anon key é pública por natureza (pode ficar no site). NÃO cole a service_role aqui.
   Enquanto estiver vazio, o app roda normal em LOCAL e só o online fica desativado. */
window.PERFIL_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
